const todoBtn = document.querySelector('.todo-list-title');
const todoAngle = document.querySelector('.todo-angle');
todoBtn.addEventListener('click', () => {
  todoAngle.classList.toggle('active');
});

const hrBtn = document.querySelector('.hr-display-title');
const hrAngle = document.querySelector('.hr-angle');
hrBtn.addEventListener('click', () => {
  hrAngle.classList.toggle('active');
});

const tipsBtn = document.querySelector('.tips-display-title');
const tipsAngle = document.querySelector('.tips-angle');
tipsBtn.addEventListener('click', () => {
  tipsAngle.classList.toggle('active');
});

// bell animation
const bell = document.querySelector('.bell');
window.onload = function () {
  bell.getAnimations;
};
